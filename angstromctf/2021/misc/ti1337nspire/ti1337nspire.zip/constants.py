import fractions
import math

pi = math.pi
tau = math.tau
e = math.e
phi = 1.618033988749895
sqrt2 = 1.414213562373095
planck = 6.62607015e-34
half = fractions.Fraction(1, 2)
