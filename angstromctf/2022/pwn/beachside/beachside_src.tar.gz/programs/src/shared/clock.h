typedef struct {
  uint64_t slot;
  uint64_t epoch_start_timestamp;
  uint64_t epoch;
  uint64_t leader_schedule_epoch;
  uint64_t unix_timestamp;
} Clock;


